var searchData=
[
  ['enclosing_354',['enclosing',['../classScope.html#a02e949882dc4066daa596e19f9bac47f',1,'Scope']]],
  ['evaluation_355',['evaluation',['../classInterpreter.html#aff2c254e3124ecb02697d6824862556c',1,'Interpreter']]]
];
