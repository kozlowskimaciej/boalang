var searchData=
[
  ['init_5ffields_358',['init_fields',['../structStructType.html#a1215952556e5c73b314f9488610b7ef8',1,'StructType']]]
];
