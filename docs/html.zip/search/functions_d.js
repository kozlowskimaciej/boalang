var searchData=
[
  ['variable_348',['Variable',['../structVariable.html#afd945a246bccd150f8a66339d9377820',1,'Variable::Variable(VarType type, std::string name, bool mut, eval_value_t value)'],['../structVariable.html#a99657ceea93b19b25bdba6e3a9d22b5e',1,'Variable::Variable(VarType type, std::string name, bool mut)']]]
];
