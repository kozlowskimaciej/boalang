var searchData=
[
  ['enclosing_5f_356',['enclosing_',['../classScope.html#a20b9aeb1b86a152291566a4e51f87a71',1,'Scope']]],
  ['evaluation_5f_357',['evaluation_',['../classInterpreter.html#a79e060c35db3ee7706aeb61d334dbc90',1,'Interpreter']]]
];
