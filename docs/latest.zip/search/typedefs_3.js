var searchData=
[
  ['stream_5fptr_384',['stream_ptr',['../source_8hpp.html#af5421297f0fb4d08651782ac8eca202e',1,'source.hpp']]]
];
