var searchData=
[
  ['define_5ffunction_323',['define_function',['../classScope.html#acf60322379f5b4454494e4ff34bcded0',1,'Scope']]],
  ['define_5ftype_324',['define_type',['../classScope.html#aaaeaceabcd7ab0f80a4d4fb9880a48cf',1,'Scope']]],
  ['define_5fvariable_325',['define_variable',['../classInterpreter.html#a4e023b1cf31ee84be56da71e51943df3',1,'Interpreter::define_variable()'],['../classScope.html#a0232c2550c5489426a902a14f1b739d4',1,'Scope::define_variable()']]]
];
